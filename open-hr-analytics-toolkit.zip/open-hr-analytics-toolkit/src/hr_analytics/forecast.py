"""Transparent, illustrative workforce and payroll cost forecasts.

All inputs in the example dataset are synthetic. This is not payroll software.
"""
from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation
from pathlib import Path

REQUIRED = ("role", "headcount", "fte_per_person", "annual_salary_eur", "employer_cost_rate")


def number(value: str, field: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise ValueError(f"Invalid number for {field}: {value!r}") from exc
    if not result.is_finite() or result < 0:
        raise ValueError(f"{field} must be a non-negative finite number")
    return result


def read_roles(path: str | Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or not set(REQUIRED).issubset(reader.fieldnames):
            raise ValueError("CSV columns required: " + ", ".join(REQUIRED))
        roles = []
        for row in reader:
            count = number(row["headcount"], "headcount")
            fte = number(row["fte_per_person"], "fte_per_person")
            salary = number(row["annual_salary_eur"], "annual_salary_eur")
            rate = number(row["employer_cost_rate"], "employer_cost_rate")
            if count != count.to_integral_value():
                raise ValueError("headcount must be a whole number")
            if fte > 1 or rate > 1:
                raise ValueError("fte_per_person and employer_cost_rate must be between 0 and 1")
            if not row["role"].strip():
                raise ValueError("role must not be empty")
            roles.append({"role": row["role"], "headcount": count, "fte": fte,
                          "salary": salary, "rate": rate})
    if not roles:
        raise ValueError("CSV must contain at least one role")
    return roles


def forecast(roles: list[dict], start_year: int = 2027, years: int = 4,
             salary_growth: Decimal = Decimal("0.02")) -> list[dict]:
    """Forecast full-year stable headcounts; no hires, vacancies, or partial years.

    Salary grows annually AFTER the first year; employer rates stay constant.
    EUR amounts are returned as Decimal values to avoid binary float artifacts.
    """
    if not 1 <= years <= 30:
        raise ValueError("years must be between 1 and 30")
    if salary_growth < 0 or salary_growth > 1:
        raise ValueError("salary_growth must be between 0 and 1")
    rows = []
    for index in range(years):
        factor = (Decimal("1") + salary_growth) ** index
        total_fte = sum((r["headcount"] * r["fte"] for r in roles), Decimal("0"))
        salary_total = sum((r["headcount"] * r["fte"] * r["salary"] * factor for r in roles), Decimal("0"))
        employer_total = sum((r["headcount"] * r["fte"] * r["salary"] * factor * r["rate"] for r in roles), Decimal("0"))
        rows.append({"year": start_year + index, "fte": total_fte,
                     "gross_salary_eur": salary_total,
                     "employer_contributions_eur": employer_total,
                     "total_employer_cost_eur": salary_total + employer_total})
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Forecast workforce costs from synthetic or your own anonymized CSV")
    parser.add_argument("--input", default="data/sample_roles.csv")
    parser.add_argument("--output", default="forecast_output.csv")
    parser.add_argument("--start-year", type=int, default=2027)
    parser.add_argument("--years", type=int, default=4)
    parser.add_argument("--salary-growth", default="0.02", help="Annual growth as decimal, e.g. 0.02 for 2%%")
    args = parser.parse_args()
    growth = number(args.salary_growth, "salary_growth")
    rows = forecast(read_roles(args.input), args.start_year, args.years, growth)
    with open(args.output, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: str(value.quantize(Decimal("0.01"))) if isinstance(value, Decimal) else value for key, value in row.items()})
    for row in rows:
        print(f'{row["year"]}: {row["fte"]} FTE; total employer cost EUR {row["total_employer_cost_eur"]:,.2f}')
    print(f"Saved forecast to {args.output}")


if __name__ == "__main__":
    main()
