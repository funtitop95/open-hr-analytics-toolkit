"""Open HR Analytics Toolkit: demonstration workforce planning utilities."""
