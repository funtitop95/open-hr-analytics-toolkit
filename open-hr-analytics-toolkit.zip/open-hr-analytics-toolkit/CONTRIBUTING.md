# Contributing

Thank you for your interest. This is an early-stage community project.

1. Open an issue describing the bug, enhancement, or documentation change.
2. Fork the repository and create a descriptive branch.
3. Add tests for code changes and run `PYTHONPATH=src python -m unittest discover -s tests -v`.
4. Open a pull request explaining what changed and why.

All code and examples must be original or appropriately licensed. Use entirely synthetic data. Do not share personal employee data, confidential financial records, or internal HR policies.

Be constructive and respectful in discussions.
