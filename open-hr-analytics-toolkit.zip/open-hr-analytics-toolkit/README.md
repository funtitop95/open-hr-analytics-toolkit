# Open HR Analytics Toolkit

**An open-source starter project for transparent workforce and payroll cost forecasting.**

![Python tests](https://img.shields.io/badge/tests-unittest-blue) ![License](https://img.shields.io/badge/license-MIT-green)

## Why it exists

HR and finance teams often need workforce-cost models they can understand, audit, and adapt without buying a full enterprise HR platform. This early-stage toolkit demonstrates a small, explainable forecasting engine for future community development.

## What works today

- Import a simple CSV listing anonymized roles, headcounts, FTE fractions, annual gross salaries, and illustrative employer contribution rates.
- Produce a multi-year forecast of FTE, gross salaries, employer contributions, and total employer cost.
- Configure the starting year, horizon, and annual salary growth rate.
- Export results to a CSV file that opens in Excel.
- Run automated tests, including GitHub Actions CI.

## Getting started

Requires **Python 3.10+**. No external dependencies and no paid account required.

From the repository folder:

```bash
PYTHONPATH=src python -m hr_analytics.forecast --input data/sample_roles.csv --start-year 2027 --years 4 --salary-growth 0.02 --output forecast_output.csv
```

On Windows PowerShell:

```powershell
$env:PYTHONPATH="src"
python -m hr_analytics.forecast --input data/sample_roles.csv --output forecast_output.csv
```

To run tests on macOS/Linux:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

The sample input is located in `data/sample_roles.csv`. **Every example is fictional.** The `forecast_output.csv` file is generated when the command runs.

## Calculation methodology

For each role, full-time-equivalent capacity is `headcount × fte_per_person`.

For year `t` (where `t=0` is the first forecast year):

- `gross_salary = headcount × fte_per_person × annual_salary × (1 + salary_growth)^t`
- `employer_contributions = gross_salary × employer_cost_rate`
- `total_employer_cost = gross_salary + employer_contributions`

Amounts are illustrative, use EUR, and are calculated with Python's `Decimal` type.

## Scope and limitations

This is a **demonstration forecasting model, not a payroll engine or legal-compliance tool**. It assumes constant headcount, full-year employment, fixed contribution rates, and a uniform growth rate. It does not currently model hiring dates, turnover, bonuses, taxes, regulatory ceilings, individual employee benefits, or country-specific payroll laws. Validate all assumptions before real-world use.

## Roadmap

- [x] A working Python forecast with CSV input/output
- [x] Automated tests
- [ ] Monthly workforce movements and partial-year hires
- [ ] Variable pay, benefits, and configurable employer contributions
- [ ] Scenario comparison and interactive dashboard
- [ ] Improved Excel integration and non-confidential tutorials

## Community and contributions

Issues and pull requests are welcome. Please review [CONTRIBUTING.md](CONTRIBUTING.md). Do not upload personal employee data, confidential information, passwords, or proprietary employer documentation.

## License

MIT — see [LICENSE](LICENSE).
