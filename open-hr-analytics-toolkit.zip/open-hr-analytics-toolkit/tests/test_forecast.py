import csv
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from hr_analytics.forecast import forecast, read_roles


class ForecastTests(unittest.TestCase):
    def test_first_year_total(self):
        roles = [{"role": "Analyst", "headcount": Decimal(2), "fte": Decimal(1),
                  "salary": Decimal(50000), "rate": Decimal("0.4")}]
        rows = forecast(roles, years=2, salary_growth=Decimal("0.1"))
        self.assertEqual(rows[0]["total_employer_cost_eur"], Decimal(140000))
        self.assertEqual(rows[1]["total_employer_cost_eur"], Decimal(154000))
        self.assertEqual(rows[0]["fte"], Decimal(2))

    def test_sample_data(self):
        self.assertEqual(len(read_roles("data/sample_roles.csv")), 4)

    def test_reject_invalid_fte(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "invalid.csv"
            with path.open("w", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(["role", "headcount", "fte_per_person", "annual_salary_eur", "employer_cost_rate"])
                writer.writerow(["Analyst", 1, "1.5", 50000, "0.4"])
            with self.assertRaises(ValueError):
                read_roles(path)


if __name__ == "__main__":
    unittest.main()
